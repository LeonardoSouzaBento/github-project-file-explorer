# GitHub File Explorer

Um visualizador de arquivos para repositórios públicos do GitHub com uma interface inspirada no VS Code.

## 📖 Como usar

### Como um Pacote NPM

1.  **Instale o pacote:**

    ```bash
    npm install @seu-usuario/git-file-explorer
    ```

2.  **Importe o componente e o CSS:**

    ```tsx
    import { Index as GitExplorer } from '@seu-usuario/git-file-explorer';
    import '@seu-usuario/git-file-explorer/dist/style.css';

    function App() {
      return (
        <GitExplorer 
          repoUrls={["https://github.com/facebook/react", "https://github.com/vercel/next.js"]}
          cssWrapper="min-h-[600px] border rounded-lg"
        />
      );
    }
    ```

### Como um Projeto Independente

1.  Cole o link de um repositório público do GitHub no campo de entrada.
2.  Clique em "Adicionar" ou pressione Enter.
3.  Navegue pela árvore de arquivos na lateral esquerda.
4.  Clique em um arquivo para abrir o conteúdo no visualizador central.
## 🚀 O que este projeto faz?

Este projeto permite que você explore e visualize o código de qualquer repositório público do GitHub de forma rápida e intuitiva, sem precisar baixar os arquivos ou sair do navegador.

### Principais Funcionalidades:

- **Exploração de Repositórios**: Adicione links de repositórios públicos e navegue pela árvore de arquivos.
- **Visualização de Código**: Veja o conteúdo dos arquivos com realce de sintaxe (syntax highlighting).
- **Interface Estilo VS Code**: Experiência de navegação familiar com barra lateral de explorador e abas de edição.
- **Gerenciamento de Repositórios**: Salve múltiplos repositórios para alternar rapidamente entre eles.
- **Status em Tempo Real**: Barra de status que mostra informações do repositório e contagem de arquivos.

## 🛠️ Tecnologias Utilizadas

- **React** (com Vite e TypeScript)
- **Tailwind CSS** (estilização)
- **Lucide React** (ícones)
- **GitHub API** (busca de dados)
- **React Syntax Highlighter** (exibição de código)
- **Shadcn UI** (componentes de interface)
